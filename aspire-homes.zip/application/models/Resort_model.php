<?php 
	class Resort_model extends CI_Model
	{
		
	}
?>