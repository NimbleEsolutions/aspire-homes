<?php 
	class Search_model extends CI_Model
	{
		
	}
?>