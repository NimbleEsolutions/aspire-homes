<div class="container error-container">
	<div class="row">
		<div class="col-md-6">
			<img src="<?= base_url(); ?>Blog/wp-content/uploads/2019/12/404-error.jpg" />
		</div>
		<div class="col-md-6">
			<h1 class="error-h1">No Results Found</h1>
			<p class="error-p">The page you requested could not be found. Try refining your search, or use the navigation above to locate the post.</p>
			<p class="error-p"><a href='<?= base_url(); ?>' class="btn btn-success">Go Home</a></p>
		</div>
	</div>
</div>
