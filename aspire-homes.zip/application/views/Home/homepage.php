<style type="text/css">
	.baner-info .row {
	    text-align: center;
	    font-size: 1em;
	    margin: 11em 0 2em 0;
	    font-weight: 500;
	    letter-spacing: 10px;
	    color: #ffcc33;
	    background: rgba(0, 0, 0, 0.45);
	    padding: 15px 0;
	    padding-top: 2%
	}
	.btn-default {
		background-color: #1cb363;
		border-color: #1cb363;
		border-radius: 4%;
		color: #ffffff;
	}
	.btn-default:hover{
		background-color: #705345;
		border-color: #705345;
		border-radius: 4%;
		color: #ffffff;
	}
	
	.w3_agileits_services_grid_agile h3:hover{
	    color:#0599a9;
	}
	
	
	.w3_agileits_services_grid{
		margin-bottom: 1%;
	}
	#carousel-custom .carousel-control.left {
	    background-image: none;
	    width: 54px;
	    height: 54px;
	    top: 50%;
	    left: 20px;
	    margin-top: -27px;
	    line-height: 54px;
	    /*border: 2px solid #fff;*/
	    opacity: 1;
	    text-shadow: none;
	    -webkit-transition: all 0.2s ease-in-out 0s;
	    -o-transition: all 0.2s ease-in-out 0s;
	    transition: all 0.2s ease-in-out 0s;
	}
	#carousel-custom .carousel-control.right {
	    background-image: none;
	    width: 54px;
	    height: 54px;
	    top: 50%;
	    right: 20px;
	    margin-top: -27px;
	    line-height: 54px;
	    /*border: 2px solid #fff;*/
	    opacity: 1;
	    text-shadow: none;
	    -webkit-transition: all 0.2s ease-in-out 0s;
	    -o-transition: all 0.2s ease-in-out 0s;
	    transition: all 0.2s ease-in-out 0s;
	}
	.w3_agileits_services_grid{
		width: 48%;
		border:0px;
	}
	.featured{
		background-color: #ffffff;
	}
	.w3l_about_bottom_right{
	 	background: #ffffff;
	}
</style>
<div class="baner-info">  
	<div class="row">
	<!-- <h3>Welcome To   <span>Feet Up </span> <span1>Holidays</span1></h3><br> -->
		<div class="col-sm-10 col-sm-offset-2">
			<form class="form-horizontal" method="get" action="<?=site_url('search')?>">
				<div class="form-group">
					<div class="col-sm-3">
						<div class="input-group date">
                        	<input type="text" name="form_dates" class="form-control" placeholder="Check In"><span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                    	</div>
					</div>
					<div class="col-sm-3">
						<div class="input-group date">
                        	<input type="text" name="till_dates" class="form-control" placeholder="Check Out"><span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                    	</div>						
					</div>
					
					<div class="col-sm-2 ">
						<select class="form-control" id="adult" name="adult">
							<option value="">Guests</option>
							<?php for ($i=1; $i <= 30; $i++) { 
								echo "<option value='".$i."'>".$i." Guests</option>";
							} ?>
						</select>
					</div>
					<div class="col-sm-2 hidden">
						<select class="form-control" name="adult">
							<option value="0">Please Select adult</option>
							<option value="1">1 adult</option>
							<option value="2">2 adult</option>
							<option value="3">3 adult</option>
							<option value="4">4 adult</option>
							<option value="5">5 adult</option>
							<option value="6">6 adult</option>
							<option value="7">7 adult</option>
							<option value="8">8 adult</option>
							<option value="9">9 adult</option>
							<option value="10">10 adult</option>
						</select>
					</div>
				
					<div class="col-sm-2 hidden">
						<select class="form-control" name="child">
							<option value="0">Please Select Childs</option>
							<option value="1">1 Child</option>
							<option value="2">2 Child</option>
							<option value="3">3 Child</option>
							<option value="4">4 Child</option>
							<option value="5">5 Child</option>
							<option value="6">6 Child</option>
							<option value="7">7 Child</option>
							<option value="8">8 Child</option>
							<option value="9">9 Child</option>
							<option value="10">10 Child</option>
						</select>
					</div>
					<div class="col-sm-2 hidden">
						<select class="form-control" name="rooms">
							<option value="0">Please Select Room</option>
							<option value="1">1</option>
							<option value="2">2</option>
							<option value="3">3</option>
							<option value="4">4</option>
							<option value="5">5</option>
							<option value="6">6</option>
							<option value="7">7</option>
							<option value="8">8</option>
							<option value="9">9</option>
							<option value="10">10</option>
						</select>
					</div>
					<div class="col-sm-2">
						<button type="submit" value="" class="btn btn-primary">Check Availability</button>
					</div>
				</div>
			</form>		
		</div>
	</div>
	<!-- <p style="font-style: oblique;">unwind explore escape</p> -->
</div>
</div>
</div>
</div>
<div class="special featured" id="destinations">
	<div class="container">
		<div class="ab-w3l-spa">
			<h3 class="tittle">Available This Weekend</span></h3>
		</div>
		<!-- services -->
		<div class="w3_agileits_services_grids" >
			<?php foreach ($destinations as $key) { ?>
			<a href="<?php echo site_url('destinations/'.$key['des_name'].'/'.$key['des_id'].'') ?>"> 
			<!-- <a href="<?php echo site_url('destResort?d='.$key['des_name'].'') ?>"> -->
			<div class="col-md-12 col-sm-12 col-xs-12 col-lg-12 w3_agileits_services_grid hvr-overline-from-center">
				<div class="w3_agileits_services_grid_agile">
					<div class="w3_agileits_services_grid_1">
					<?php if($key['des_img'] == ''){ ?>
						<img src="<?=base_url()?>assets/images/image-not-available.jpg" alt="service-img">
					<?php }else{ ?>
						<img src="<?php echo $key['des_img']; ?>" alt="service-img" style="border-radius: 10px;">
					<?php } ?>
					</div>
					<h3><b><?php echo ucfirst(strtolower($key['des_name'])); ?></b></h3>
				</div>
			</div>
			</a>	
			<?php } ?>
			<div class="clearfix"> </div>
		</div>
	</div>
</div>
<div class="special featured" id="packages">
	<div class="container">
		<div class="ab-w3l-spa">
			<h3 class="tittle">Special Packages section</span></h3>
		</div>
		<!-- services -->
			<?php foreach ($packages as $key) { ?>
			<a href="<?php echo site_url('package?pk='.$key['pt_name'].'') ?>">
				<div class="w3_agileits_services_grids" >
					<div class="col-sm-12 col-md-12 col-lg-12 col-xs-12" id="packages_section" style="border-radius:10px;">
						<div class="col-sm-12 col-md-6 col-lg-6 col-xs-12" style="padding-right:0px;">
							<img src="//res.cloudinary.com/www-saffronstays-com/image/upload/f_auto,fl_force_strip.progressive:steep,c_limit,q_40,e_auto_contrast,h_800,w_1500/v1600154230/p8qwoaepqkvzx5ouvihr.jpg" style="width: 100%;height: 280px;border-top-left-radius: 10px;border-bottom-left-radius: 10px;">
						</div>
						<div class="col-sm-12 col-md-6 col-lg-6 col-xs-12" style="padding-left:0px;background-color: #000000;height: 280px;padding: 7% 0;text-align: center;border-top-right-radius: 10px;border-bottom-right-radius: 10px;">
							<img src="https://res.cloudinary.com/www-saffronstays-com/image/upload/h_100,w_320/v1/mewtwo/images/Final_INTRO_X_Series.svg" alt="" height="100" width="320">
						</div>
					</div>
				</div>
			</a>
			<?php } ?>
			<div class="clearfix"> </div>
		</div>
	</div>
</div>
<div style="padding: 2em;">
    <h3 class="tittle">Guest's Reviews</h3>
</div>
<div class="guests-agile" style="padding-top: 3em;">
	<a href="https://aspirevillastays.com/Blog/" target="_blank"><span class="btn btn-primary" style="writing-mode: vertical-rl;transform: rotate(0deg); background-color: #f47720;border-color: #f47720;font-weight: bold;padding-left: 2%;font-size:large;width: 10px;border-top-right-radius: 20px;border-bottom-right-radius: 20px;border-top-right-radius: 20px;
		    border-bottom-right-radius: 20px;font: normal normal normal 14px/1 FontAwesome;font-size: 1.33333333em;"><i class="fa fa-list "></i> All Reviews</span></a>
	<div class="w3_agileits_testimonial_grids">
		<section class="slider">
			<div class="flexslider">
				<ul class="slides">
					<?php if(!empty($review)){foreach ($review as $key) { ?>
					<li>
						<div class="w3_agileits_testimonial_grid">
							<i class="fa fa-quote-right" aria-hidden="true"></i>
							<p><?php echo $key['post_excerpt']; ?></p>
							<img src="<?=base_url()?>assets/images/aspire-logo-web.png" style="width: 10%;"alt=" " class="img-responsive" />
							<p><?php echo substr($key['post_title'],19,(strrpos($key['post_title'], 'stayed')-19)); ?></p>
						</div>
					</li>
					<?php } }else{ ?>
					<li>
						<div class="w3_agileits_testimonial_grid">
							<i class="fa fa-quote-right" aria-hidden="true"></i>
							<p><?php echo "Welcome to post first review."; ?></p>
							<img src="<?=base_url()?>assets/images/aspire-logo-web.png" style="width: 10%;" alt=" " class="img-responsive" />
						</div>
					</li>
					<?php } ?>
				</ul>
			</div>
		</section>

		<!-- //flexSlider -->
	</div>
</div>
<!-- //testimonials -->
